# config.py

# Telegram bot token
TOKEN = "Paste Bot Token"
