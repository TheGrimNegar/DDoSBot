# Trixsec-DDOS-BOT


<i>Any actions and or activities related to <b>Trixsec Bot</b> is solely your responsibility. The misuse of this toolkit can result in <b>criminal charges</b> brought against the persons in question. <b>The author will not be held responsible</b> in the event any criminal charges be brought against any individuals misusing this toolkit to break the law.

<b>This toolkit contains materials that can be potentially damaging or dangerous for internet</b>. Refer to the laws in your province/country before accessing, using,or in any other way utilizing this in a wrong way.

<b>This Tool is made for educational purposes only</b>. Do not attempt to violate the law with anything contained here.!
</i>
### Features Convert Your Telegram Bot Into DDOS Attack Launching Machine 

### Requirements: Create A Bot From @BotFather and paste the bot token in config.py file 


- All Methods
  - HTTP-FLOOD
  - HTTP-RAW
  - HTTP-RAND
  - HTTP-SOCKET
  - CLOUDFLARE
  - UAM-BYPASS
  - SLOW
- New methods will be updated soon...
### Installation
- Installation for Windows
- Install Python, Nodejs, Golang
  ```
  https://www.python.org/downloads/
  https://nodejs.org/en/download/
  https://go.dev/dl/
  ```
- Installation for Linux
  ```
  apt-get install golang -y
  apt-get install python3 -y
  apt-get install python2 -y
  apt-get install python3-pip -y
  apt-get install nodejs -y
  apt-get install npm -y
  npm i requests
  npm i https-proxy-agent
  npm i crypto-random-string
  npm i events
  npm i fs
  npm i net
  npm i cloudscraper
  npm i request
  npm i hcaptcha-solver
  npm i randomstring
  npm i cluster
  npm i cloudflare-bypasser
  ```
- Clone this repository -
  ```
  git clone https://github.com/TrixSec/Trixsec-DDOS-BOT
  ```
- Now go to run `trixsec-ddosbot-v1.py` -
  ```
  $ cd Trixsec-DDOS-BOT
  $ paste the bot token in config.py file 
  $ python3 trixsec-ddosbot-v1.py
  ```

## JOIN US ON TELEGRAM


[![Telegram](https://upload.wikimedia.org/wikipedia/commons/thumb/8/82/Telegram_logo.svg/240px-Telegram_logo.svg.png)](https://t.me/Trixsec)
